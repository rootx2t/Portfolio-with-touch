import { Navigation } from "@/components/Navigation";
import { HeroSection } from "@/components/HeroSection";
import { TrackRecordSection } from "@/components/TrackRecordSection";
import { CrisisSection } from "@/components/CrisisSection";
import { StackSection } from "@/components/StackSection";
import { AboutSection } from "@/components/AboutSection";
import { ContactSection } from "@/components/ContactSection";
import { Footer } from "@/components/Footer";
import { Helmet } from "react-helmet-async";

const Index = () => {
  return (
    <>
      <Helmet>
        <title>CM.Protocol | Web3 Community Manager & Marketing Lead</title>
        <meta 
          name="description" 
          content="Scaling Web3 communities from zero to hero. Expert in community growth, crisis management, and building loyal user bases for CEX and DEX platforms." 
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Helmet>
      
      <div className="min-h-screen bg-background">
        <Navigation />
        <main>
          <HeroSection />
          <TrackRecordSection />
          <CrisisSection />
          <StackSection />
          <AboutSection />
          <ContactSection />
        </main>
        <Footer />
      </div>
    </>
  );
};

export default Index;
