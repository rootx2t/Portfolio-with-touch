import { Quote } from "lucide-react";
import { motion } from "framer-motion";

export const AboutSection = () => {
  return (
    <section id="about" className="py-24 relative bg-card/50">
      <div className="absolute inset-0 noise" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left: Image & Visual */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.7 }}
            className="relative"
          >
            <div className="aspect-square max-w-md mx-auto relative">
              {/* Decorative elements */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-accent/20 rounded-2xl" />
              <div className="absolute -inset-4 border border-primary/10 rounded-3xl" />
              <div className="absolute -inset-8 border border-accent/5 rounded-3xl" />
              
              {/* Profile placeholder */}
              <div className="absolute inset-0 glass rounded-2xl flex items-center justify-center">
                <div className="text-center p-8">
                  <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-gradient-to-br from-primary to-accent p-1">
                    <div className="w-full h-full rounded-full bg-background flex items-center justify-center">
                      <span className="text-4xl font-bold text-gradient">CM</span>
                    </div>
                  </div>
                  <p className="text-muted-foreground font-mono text-sm">
                    // Your Photo Here
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right: Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.7 }}
          >
            <p className="text-primary font-mono text-sm mb-4">// ABOUT ME</p>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              From Degen to
              <br />
              <span className="text-gradient">Community Architect</span>
            </h2>

            <div className="space-y-4 text-muted-foreground mb-8">
              <p>
                I fell down the crypto rabbit hole in 2019. What started as aping into 
                random tokens became a deep fascination with what makes Web3 communities tick.
              </p>
              <p>
                I've been on both sides—as a community member losing sleep over an exploit, 
                and as the person reassuring thousands that everything would be okay. 
                That experience shaped how I approach community management.
              </p>
              <p>
                Today, I specialize in building communities that don't just survive bear markets—they 
                thrive in them. I believe in transparency, data-driven decisions, and treating every 
                community member like the early adopter they are.
              </p>
            </div>

            {/* Quote */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="glass rounded-xl p-6 border-l-4 border-primary"
            >
              <Quote className="h-6 w-6 text-primary mb-3" />
              <p className="text-foreground italic">
                "Community isn't a growth hack. It's the foundation of every successful Web3 project."
              </p>
            </motion.div>

            {/* Fun Facts */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="mt-8 grid grid-cols-2 gap-4"
            >
              <div className="glass rounded-lg p-4">
                <p className="text-sm text-muted-foreground mb-1">Time Zone</p>
                <p className="font-mono text-foreground">UTC +0 (Flexible)</p>
              </div>
              <div className="glass rounded-lg p-4">
                <p className="text-sm text-muted-foreground mb-1">Languages</p>
                <p className="font-mono text-foreground">EN / ES / Meme</p>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
