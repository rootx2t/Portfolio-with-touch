import { Mail, Send, Twitter, MessageSquare, FileText, ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";

const socialLinks = [
  { icon: Twitter, label: "Twitter/X", href: "#", handle: "@yourhandle" },
  { icon: Send, label: "Telegram", href: "#", handle: "@yourhandle" },
  { icon: MessageSquare, label: "Discord", href: "#", handle: "yourname#0000" },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5 },
  },
};

export const ContactSection = () => {
  return (
    <section id="contact" className="py-24 relative">
      <div className="absolute inset-0 noise" />
      
      {/* Gradient accents */}
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-[128px]" />
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-accent/5 rounded-full blur-[128px]" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Section Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <p className="text-primary font-mono text-sm mb-4">// LET'S CONNECT</p>
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              Ready to Scale Your
              <br />
              <span className="text-gradient">Community?</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Whether you're launching a new project or looking to level up your existing community, 
              I'd love to hear from you. Let's build something legendary.
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6 }}
              className="glass rounded-2xl p-8"
            >
              <h3 className="text-xl font-bold text-foreground mb-6">Send a Message</h3>
              <form className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-muted-foreground mb-2 block">Name</label>
                    <Input 
                      placeholder="Your name" 
                      className="bg-secondary/50 border-border focus:border-primary"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground mb-2 block">Company</label>
                    <Input 
                      placeholder="Your company" 
                      className="bg-secondary/50 border-border focus:border-primary"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground mb-2 block">Email</label>
                  <Input 
                    type="email" 
                    placeholder="you@example.com" 
                    className="bg-secondary/50 border-border focus:border-primary"
                  />
                </div>
                <div>
                  <label className="text-sm text-muted-foreground mb-2 block">Message</label>
                  <Textarea 
                    placeholder="Tell me about your project..." 
                    rows={4}
                    className="bg-secondary/50 border-border focus:border-primary resize-none"
                  />
                </div>
                <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 glow-primary">
                  <Mail className="mr-2 h-4 w-4" />
                  Send Message
                </Button>
              </form>
            </motion.div>

            {/* Social & Quick Links */}
            <motion.div
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              className="space-y-6"
            >
              {/* Social Links */}
              <motion.div variants={itemVariants} className="glass rounded-2xl p-8">
                <h3 className="text-xl font-bold text-foreground mb-6">Connect Directly</h3>
                <div className="space-y-4">
                  {socialLinks.map((link) => (
                    <motion.a
                      key={link.label}
                      href={link.href}
                      whileTap={{ scale: 0.97 }}
                      whileHover={{ scale: 1.02 }}
                      className="flex items-center justify-between p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors group"
                    >
                      <div className="flex items-center gap-3">
                        <link.icon className="h-5 w-5 text-primary" />
                        <div>
                          <p className="text-foreground font-medium">{link.label}</p>
                          <p className="text-sm text-muted-foreground font-mono">{link.handle}</p>
                        </div>
                      </div>
                      <ArrowUpRight className="h-4 w-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 group-hover:-translate-y-1 transition-all" />
                    </motion.a>
                  ))}
                </div>
              </motion.div>

              {/* Resume Download */}
              <motion.div variants={itemVariants} className="glass rounded-2xl p-8">
                <h3 className="text-xl font-bold text-foreground mb-4">Quick Access</h3>
                <p className="text-muted-foreground text-sm mb-6">
                  Download my resume or schedule a call directly.
                </p>
                <div className="space-y-3">
                  <Button variant="outline" className="w-full border-border hover:bg-secondary/50">
                    <FileText className="mr-2 h-4 w-4" />
                    Download Resume (PDF)
                  </Button>
                  <Button variant="outline" className="w-full border-primary/30 hover:bg-primary/10 text-primary">
                    <Mail className="mr-2 h-4 w-4" />
                    Schedule a Call
                  </Button>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};
