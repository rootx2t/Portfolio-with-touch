import { 
  MessageSquare, 
  BarChart3, 
  Bot, 
  Shield, 
  Users, 
  Megaphone,
  Webhook,
  Database
} from "lucide-react";
import { motion } from "framer-motion";

const toolCategories = [
  {
    title: "Community Platforms",
    icon: MessageSquare,
    color: "primary",
    tools: [
      { name: "Discord", level: 95 },
      { name: "Telegram", level: 98 },
      { name: "Twitter/X", level: 90 },
      { name: "Reddit", level: 75 },
    ],
  },
  {
    title: "Analytics & Insights",
    icon: BarChart3,
    color: "chart-2",
    tools: [
      { name: "Dune Analytics", level: 85 },
      { name: "Nansen", level: 80 },
      { name: "Google Analytics", level: 90 },
      { name: "Mixpanel", level: 75 },
    ],
  },
  {
    title: "Automation & Bots",
    icon: Bot,
    color: "accent",
    tools: [
      { name: "MEE6 / Carl-bot", level: 95 },
      { name: "Combot (Telegram)", level: 90 },
      { name: "Collab.Land", level: 88 },
      { name: "IFTTT / Zapier", level: 85 },
    ],
  },
  {
    title: "Moderation & Security",
    icon: Shield,
    color: "chart-4",
    tools: [
      { name: "Rose Bot", level: 92 },
      { name: "Group Help Bot", level: 88 },
      { name: "Anti-Spam Tools", level: 95 },
      { name: "Wallet Verification", level: 85 },
    ],
  },
  {
    title: "CRM & User Management",
    icon: Users,
    color: "chart-5",
    tools: [
      { name: "Notion", level: 95 },
      { name: "HubSpot", level: 70 },
      { name: "Airtable", level: 85 },
      { name: "Intercom", level: 72 },
    ],
  },
  {
    title: "Marketing & Campaigns",
    icon: Megaphone,
    color: "chart-3",
    tools: [
      { name: "Galxe", level: 88 },
      { name: "Layer3", level: 85 },
      { name: "Zealy (Crew3)", level: 90 },
      { name: "QuestN", level: 80 },
    ],
  },
];

const integrations = [
  { icon: Webhook, label: "API Integrations" },
  { icon: Database, label: "On-chain Data" },
  { icon: Bot, label: "Custom Bots" },
  { icon: BarChart3, label: "Dashboard Building" },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5 },
  },
};

export const StackSection = () => {
  return (
    <section id="stack" className="py-24 relative">
      <div className="absolute inset-0 noise" />
      
      <div className="container mx-auto px-6 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl mb-16"
        >
          <p className="text-primary font-mono text-sm mb-4">// THE STACK</p>
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            Tools of the
            <br />
            <span className="text-gradient">Trade</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            From Discord bots to on-chain analytics, here's the arsenal I use 
            to build, manage, and scale Web3 communities.
          </p>
        </motion.div>

        {/* Tools Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16"
        >
          {toolCategories.map((category) => (
            <motion.div
              key={category.title}
              variants={itemVariants}
              whileTap={{ scale: 0.97 }}
              whileHover={{ scale: 1.02 }}
              className="glass rounded-xl p-6 hover:border-primary/30 transition-all duration-300"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className={`p-2 rounded-lg bg-${category.color}/10`}>
                  <category.icon className={`h-6 w-6 text-${category.color}`} />
                </div>
                <h3 className="font-bold text-foreground">{category.title}</h3>
              </div>
              
              <div className="space-y-4">
                {category.tools.map((tool) => (
                  <div key={tool.name}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-foreground">{tool.name}</span>
                      <span className="text-muted-foreground font-mono">{tool.level}%</span>
                    </div>
                    <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full bg-gradient-to-r from-${category.color} to-${category.color}/60`}
                        style={{ width: `${tool.level}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Additional Skills */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="glass rounded-xl p-8"
        >
          <h3 className="text-xl font-bold text-foreground mb-6">Technical Capabilities</h3>
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4"
          >
            {integrations.map((item) => (
              <motion.div
                key={item.label}
                variants={itemVariants}
                whileTap={{ scale: 0.93 }}
                whileHover={{ scale: 1.05 }}
                className="flex flex-col items-center p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
              >
                <item.icon className="h-8 w-8 text-primary mb-2" />
                <span className="text-sm text-foreground text-center">{item.label}</span>
              </motion.div>
            ))}
          </motion.div>
          <p className="text-muted-foreground text-sm mt-6 text-center">
            I don't just use tools—I customize and connect them to create seamless community experiences.
          </p>
        </motion.div>
      </div>
    </section>
  );
};
