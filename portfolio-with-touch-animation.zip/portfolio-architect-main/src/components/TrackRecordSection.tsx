import { ArrowUpRight, Users, MessageSquare, TrendingUp, Zap } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";

const caseStudies = [
  {
    company: "DeFi Protocol X",
    role: "Community Lead",
    period: "2022 - 2023",
    metrics: [
      { label: "Telegram Growth", value: "0 → 52K", icon: Users },
      { label: "Discord DAU", value: "+340%", icon: MessageSquare },
      { label: "TVL Impact", value: "$12M", icon: TrendingUp },
    ],
    tags: ["Telegram", "Discord", "Twitter Spaces"],
    description: "Built the community from scratch during bear market conditions. Implemented ambassador program that drove organic growth without paid acquisition.",
    gradient: "from-primary to-chart-2",
  },
  {
    company: "CEX Platform Y",
    role: "Marketing Manager",
    period: "2021 - 2022",
    metrics: [
      { label: "User Acquisition", value: "+85K", icon: Users },
      { label: "Trading Volume", value: "+$28M", icon: TrendingUp },
      { label: "Retention Rate", value: "67%", icon: Zap },
    ],
    tags: ["KOL Management", "Campaigns", "Analytics"],
    description: "Led regional expansion across Southeast Asia. Managed influencer partnerships and localized community strategies that outperformed industry benchmarks.",
    gradient: "from-chart-2 to-accent",
  },
  {
    company: "NFT Marketplace Z",
    role: "Head of Community",
    period: "2023 - Present",
    metrics: [
      { label: "Active Collectors", value: "18K+", icon: Users },
      { label: "Floor Price", value: "+120%", icon: TrendingUp },
      { label: "Community Events", value: "50+", icon: MessageSquare },
    ],
    tags: ["NFT Culture", "IRL Events", "Holder Benefits"],
    description: "Transformed a struggling project into a thriving ecosystem. Introduced holder-exclusive perks and cross-community collaborations.",
    gradient: "from-accent to-chart-4",
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6 },
  },
};

export const TrackRecordSection = () => {
  return (
    <section id="track-record" className="py-24 relative">
      <div className="absolute inset-0 noise" />
      
      <div className="container mx-auto px-6 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl mb-16"
        >
          <p className="text-primary font-mono text-sm mb-4">// THE TRACK RECORD</p>
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            Results That Speak
            <br />
            <span className="text-gradient">Louder Than Hype</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            Every metric backed by data. Every community built with strategy.
            Here's the proof that community-led growth isn't just a buzzword.
          </p>
        </motion.div>

        {/* Case Studies */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="space-y-8"
        >
          {caseStudies.map((study) => (
            <motion.div
              key={study.company}
              variants={itemVariants}
              whileTap={{ scale: 0.98 }}
              whileHover={{ scale: 1.01 }}
              className="glass rounded-2xl p-8 hover:border-primary/30 transition-all duration-300 group"
            >
              <div className="flex flex-col lg:flex-row lg:items-start gap-8">
                {/* Left: Company Info */}
                <div className="lg:w-1/3">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-foreground group-hover:text-primary transition-colors">
                        {study.company}
                      </h3>
                      <p className="text-muted-foreground">{study.role}</p>
                    </div>
                    <ArrowUpRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 group-hover:-translate-y-1 transition-all" />
                  </div>
                  <p className="text-sm text-muted-foreground mb-4 font-mono">{study.period}</p>
                  <div className="flex flex-wrap gap-2">
                    {study.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="bg-secondary text-secondary-foreground">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Middle: Metrics */}
                <div className="lg:w-1/3">
                  <div className="grid grid-cols-3 gap-4">
                    {study.metrics.map((metric) => (
                      <div key={metric.label} className="text-center">
                        <metric.icon className="h-5 w-5 mx-auto mb-2 text-primary" />
                        <div className={`text-xl font-bold bg-gradient-to-r ${study.gradient} bg-clip-text text-transparent`}>
                          {metric.value}
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">{metric.label}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right: Description */}
                <div className="lg:w-1/3">
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {study.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};
