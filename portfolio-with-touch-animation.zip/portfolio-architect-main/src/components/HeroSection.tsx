import { ArrowRight, TrendingUp, Users, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background Effects */}
      <div className="absolute inset-0 noise" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[128px] animate-pulse-slow" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-[128px] animate-pulse-slow" style={{ animationDelay: "2s" }} />
      
      {/* Grid Pattern */}
      <div 
        className="absolute inset-0 opacity-[0.02]"
        style={{
          backgroundImage: `linear-gradient(hsl(var(--foreground)) 1px, transparent 1px),
                           linear-gradient(90deg, hsl(var(--foreground)) 1px, transparent 1px)`,
          backgroundSize: "60px 60px",
        }}
      />

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Tag */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-8"
          >
            <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            <span className="text-sm text-muted-foreground font-mono">COMMUNITY GROWTH SPECIALIST</span>
          </motion.div>

          {/* Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight mb-6"
          >
            I Turn Communities Into
            <br />
            <span className="text-gradient">Revenue Engines</span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10"
          >
            Scaling Web3 communities from zero to hero. Growing trading volumes through engagement, 
            managing FUD like a pro, and building loyal user bases that convert.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-4 justify-center mb-16"
          >
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 glow-primary group">
              View Case Studies
              <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button size="lg" variant="outline" className="border-border hover:bg-secondary/50">
              Download Resume
            </Button>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6"
          >
            <motion.div 
              whileTap={{ scale: 0.97 }}
              whileHover={{ scale: 1.02 }}
              className="glass rounded-xl p-6 hover:border-primary/30 transition-colors cursor-pointer"
            >
              <Users className="h-8 w-8 text-primary mb-3 mx-auto" />
              <div className="text-3xl font-bold text-foreground mb-1">250K+</div>
              <div className="text-sm text-muted-foreground">Community Members Grown</div>
            </motion.div>
            <motion.div 
              whileTap={{ scale: 0.97 }}
              whileHover={{ scale: 1.02 }}
              className="glass rounded-xl p-6 hover:border-primary/30 transition-colors cursor-pointer"
            >
              <TrendingUp className="h-8 w-8 text-chart-2 mb-3 mx-auto" />
              <div className="text-3xl font-bold text-foreground mb-1">$50M+</div>
              <div className="text-sm text-muted-foreground">Trading Volume Influenced</div>
            </motion.div>
            <motion.div 
              whileTap={{ scale: 0.97 }}
              whileHover={{ scale: 1.02 }}
              className="glass rounded-xl p-6 hover:border-primary/30 transition-colors cursor-pointer"
            >
              <Shield className="h-8 w-8 text-accent mb-3 mx-auto" />
              <div className="text-3xl font-bold text-foreground mb-1">15+</div>
              <div className="text-sm text-muted-foreground">Crisis Events Managed</div>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 rounded-full border-2 border-muted-foreground/30 flex justify-center pt-2">
          <div className="w-1.5 h-3 bg-primary rounded-full animate-pulse" />
        </div>
      </div>
    </section>
  );
};
