import { Shield, Clock, MessageCircle, AlertTriangle, CheckCircle, Zap } from "lucide-react";
import { motion } from "framer-motion";

const crisisEvents = [
  {
    title: "Smart Contract Exploit",
    severity: "Critical",
    response: "< 15 min",
    outcome: "Zero user fund loss, maintained community trust",
    actions: [
      "Coordinated immediate transparent communication",
      "Set up 24/7 monitoring war room",
      "Drafted FAQ addressing all user concerns",
      "Managed bridge to recovery plan announcement",
    ],
  },
  {
    title: "Exchange Downtime (6+ hours)",
    severity: "High",
    response: "< 5 min",
    outcome: "95% sentiment recovery within 48 hours",
    actions: [
      "Real-time status updates every 30 minutes",
      "Proactive FUD management on Twitter",
      "Compensation program communication",
      "Post-mortem transparency report",
    ],
  },
  {
    title: "Coordinated FUD Attack",
    severity: "Medium",
    response: "< 30 min",
    outcome: "Turned critics into community members",
    actions: [
      "Identified attack vectors and key spreaders",
      "Deployed fact-check resources",
      "Activated community advocates",
      "Created meme response campaign",
    ],
  },
];

const principles = [
  {
    icon: Clock,
    title: "Speed First",
    description: "First response within 15 minutes. Silence breeds FUD faster than bad news.",
  },
  {
    icon: MessageCircle,
    title: "Radical Transparency",
    description: "Tell them what happened, what you're doing, and when they'll hear from you next.",
  },
  {
    icon: Shield,
    title: "Own The Narrative",
    description: "Control the information flow. If you don't tell the story, someone else will.",
  },
  {
    icon: Zap,
    title: "Turn Crisis Into Trust",
    description: "Every crisis handled well is an opportunity to deepen community loyalty.",
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5 },
  },
};

export const CrisisSection = () => {
  return (
    <section id="crisis" className="py-24 relative bg-card/50">
      <div className="absolute inset-0 noise" />
      
      {/* Warning stripe accent */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-chart-4 via-chart-5 to-chart-4" />
      
      <div className="container mx-auto px-6 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl mb-16"
        >
          <p className="text-chart-4 font-mono text-sm mb-4">// CRISIS MANAGEMENT</p>
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            When Things Go South,
            <br />
            <span className="text-chart-4">I Keep It Together</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            Exploits, downtimes, FUD storms—I've navigated them all. 
            Here's how I turn potential disasters into trust-building moments.
          </p>
        </motion.div>

        {/* Principles Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16"
        >
          {principles.map((principle) => (
            <motion.div
              key={principle.title}
              variants={itemVariants}
              whileTap={{ scale: 0.95 }}
              whileHover={{ scale: 1.03 }}
              className="glass rounded-xl p-6 hover:border-chart-4/30 transition-all duration-300"
            >
              <principle.icon className="h-8 w-8 text-chart-4 mb-4" />
              <h3 className="font-bold text-foreground mb-2">{principle.title}</h3>
              <p className="text-sm text-muted-foreground">{principle.description}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* Crisis Timeline */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="space-y-6"
        >
          <motion.h3 variants={itemVariants} className="text-xl font-bold text-foreground mb-8">
            Battle-Tested Scenarios
          </motion.h3>
          {crisisEvents.map((event) => (
            <motion.div
              key={event.title}
              variants={itemVariants}
              whileTap={{ scale: 0.98 }}
              whileHover={{ scale: 1.01 }}
              className="glass rounded-xl p-6 hover:border-chart-4/30 transition-all duration-300"
            >
              <div className="flex flex-col lg:flex-row gap-6">
                {/* Event Header */}
                <div className="lg:w-1/4">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle className={`h-5 w-5 ${
                      event.severity === "Critical" ? "text-destructive" :
                      event.severity === "High" ? "text-chart-5" : "text-chart-4"
                    }`} />
                    <span className={`text-xs font-mono px-2 py-1 rounded ${
                      event.severity === "Critical" ? "bg-destructive/20 text-destructive" :
                      event.severity === "High" ? "bg-chart-5/20 text-chart-5" : "bg-chart-4/20 text-chart-4"
                    }`}>
                      {event.severity}
                    </span>
                  </div>
                  <h4 className="text-lg font-bold text-foreground">{event.title}</h4>
                  <p className="text-sm text-muted-foreground font-mono mt-2">
                    Response: {event.response}
                  </p>
                </div>

                {/* Actions */}
                <div className="lg:w-1/2">
                  <p className="text-sm text-muted-foreground mb-3">Key Actions:</p>
                  <ul className="space-y-2">
                    {event.actions.map((action, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                        <CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                        {action}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Outcome */}
                <div className="lg:w-1/4">
                  <div className="bg-primary/10 rounded-lg p-4 border border-primary/20">
                    <p className="text-xs text-primary font-mono mb-1">OUTCOME</p>
                    <p className="text-sm text-foreground font-medium">{event.outcome}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};
