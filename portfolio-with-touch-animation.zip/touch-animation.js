
document.addEventListener("touchstart", function(e){
  const el = e.target.closest("a, button, .card, .btn");
  if(!el) return;
  el.classList.add("touch-ripple","active");
  setTimeout(()=>el.classList.remove("active"),600);
}, {passive:true});
